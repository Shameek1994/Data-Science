
--SQL Advance Case Study
use db_SQLCaseStudies

select * from dim_date
select * from dim_model
select * from DIM_MANUFACTURER
select * from fact_transactions
select * from dim_customer
select * from dim_location

--Q1--BEGIN 

select l.state,c.customer_name,t.date
from dim_location l 
inner join 
fact_transactions t	on l.idlocation=t.idlocation
inner join
dim_customer c on t.idcustomer=c.idcustomer
where 
Year(t.date) >= 2005  

--Q1--END

--Q2--BEGIN
	
Select top 1 l.State, Sum(t.quantity) as quantities_bought
from dim_location l 
inner join 
fact_transactions t	on l.idlocation=t.idlocation
inner join
dim_model m on m.idmodel=t.idmodel 
inner join
dim_manufacturer dm on dm.idmanufacturer=m.idmanufacturer
where l.country='US'
and dm.manufacturer_name='Samsung'
group by l.State
order by 2 desc

--Q2--END

--Q3--BEGIN      
	
select l.zipcode,l.state,m.Model_Name,count(t.IDCustomer) as count_of_transactions 
from dim_location l 
inner join 
fact_transactions t	on l.idlocation=t.idlocation
inner join
dim_model m on m.idmodel=t.idmodel 
group by l.zipcode,l.state,m.Model_Name

--Q3--END

--Q4--BEGIN

--Based on Unit Price

select top 1 dm.Manufacturer_name, m.Model_name,min(m.Unit_price) as unit_price
from 
dim_model m
inner join
dim_manufacturer dm on dm.idmanufacturer=m.idmanufacturer
group by dm.Manufacturer_name, m.Model_name
order by 3 asc

--Based on Transactions

select top 1 t.IDLocation,dm.Manufacturer_name, m.Model_name, cast(t.totalPrice/t.quantity as float) as Price
from 
dim_model m
inner join
dim_manufacturer dm on dm.idmanufacturer=m.idmanufacturer
inner join 
fact_transactions t on t.IDModel=m.IDModel
inner join 
dim_location l on l.idlocation=t.idlocation
order by 4

--Q4--END

--Q5--BEGIN

select dm.Manufacturer_Name,m.model_name,AVG(t.Totalprice) as Average_Price
from 
dim_model m
inner join
dim_manufacturer dm on dm.idmanufacturer=m.idmanufacturer
inner join 
fact_transactions t on t.IDModel=m.IDModel
where dm.Manufacturer_Name in (select top 5 dm.Manufacturer_Name
--Sum(t.Quantity) as Total_Sales_quantity
from DIM_MANUFACTURER dm inner join
dim_model m on dm.idmanufacturer=m.idmanufacturer
inner join 
fact_transactions t on t.IDModel=m.IDModel
group by dm.Manufacturer_Name
order by Sum(t.Quantity) desc)
group by dm.Manufacturer_Name,m.model_name
order by Average_Price 

--Q5--END

--Q6--BEGIN

select c.customer_name, avg(t.totalprice) as Average_Amount_Spent_2009
from fact_transactions t
inner join
dim_customer c on t.idcustomer=c.idcustomer
where year(t.Date)='2009'
group by c.customer_name
having avg(t.totalprice)>500

--Q6--END
	
--Q7--BEGIN  
	
select * from (Select top 5 m.Model_Name
from 
dim_model m
inner join 
fact_transactions t on t.IDModel=m.IDModel
where YEAR(t.date) = '2008'
group by m.Model_Name	
order by sum(t.quantity) desc) as T1
intersect
select * from 
(Select top 5 m.Model_Name
from 
dim_model m
inner join 
fact_transactions t on t.IDModel=m.IDModel
where YEAR(t.date) = '2009'
group by m.Model_Name	
order by sum(t.quantity) desc) as T2
intersect
select * from 
(Select top 5 m.Model_Name
from 
dim_model m
inner join 
fact_transactions t on t.IDModel=m.IDModel
where YEAR(t.date) = '2010'
group by m.Model_Name	
order by sum(t.quantity) desc) as T3

--Q7--END	
--Q8--BEGIN

select top 1 * from ((select Manufacturer_Name,Sum(t.Quantity) as quantity_sold, 
YEAR(t.date) as Year_of_transaction
from DIM_MANUFACTURER dm
inner join DIM_MODEL m on m.IDManufacturer=dm.IDManufacturer
inner join FACT_TRANSACTIONS t on m.IDModel=t.IDModel
where YEAR(t.Date)='2009' 
group by Manufacturer_Name,YEAR(t.date)
order by 2 desc
offset 1 rows )as t1
full join
(select Manufacturer_Name,Sum(t.Quantity) as quantity_sold,YEAR(t.date) as Year_of_transaction
from DIM_MANUFACTURER dm
inner join DIM_MODEL m on m.IDManufacturer=dm.IDManufacturer
inner join FACT_TRANSACTIONS t on m.IDModel=t.IDModel
where YEAR(t.Date)='2010'
group by Manufacturer_Name,YEAR(t.date)
order by 2 desc
offset 1 rows) as t2 on t1.Manufacturer_Name=t2.Manufacturer_Name)

--Q8--END
--Q9--BEGIN
	
select distinct dm.Manufacturer_Name
from 
dim_manufacturer dm
inner join
DIM_MODEL mo on dm.IDManufacturer=mo.IDManufacturer
inner join 
FACT_TRANSACTIONS t on t.IDModel=mo.IDModel
where year(t.Date)='2010'
except 
select distinct dm.Manufacturer_Name
from 
dim_manufacturer dm
inner join
DIM_MODEL mo on dm.IDManufacturer=mo.IDManufacturer
inner join 
FACT_TRANSACTIONS t on t.IDModel=mo.IDModel
where year(t.Date)='2009'

--Q9--END

--Q10--BEGIN


SELECT T1.Customer_Name, T1.[Year], T1.Average_Spend,T1.Average_quantity,
CASE WHEN t2.[Year] IS NOT NULL THEN FORMAT(CONVERT(float,(T1.Average_Spend-T2.Average_Spend))/CONVERT(float,T2.Average_Spend),'p') ELSE NULL END AS 'YEARLY_Percentage_CHANGE'
from (select c.customer_name,
AVG(t.totalprice) as Average_Spend,
AVG(t.quantity) as Average_quantity,
year(t.date) as [Year] 
from FACT_TRANSACTIONS t inner join
DIM_CUSTOMER c on c.IDCustomer=t.IDCustomer 
where c.IDCustomer in (select top 100 t.IDCustomer from FACT_TRANSACTIONS t inner join
DIM_CUSTOMER c on c.IDCustomer=t.IDCustomer group by t.IDCustomer order by sum(t.TotalPrice) desc)
group by c.customer_name,year(t.date))t1
inner join 
(select c.customer_name,
AVG(t.totalprice) as Average_Spend,
AVG(t.quantity) as Average_quantity,
year(t.date) as [Year] 
from FACT_TRANSACTIONS t inner join
DIM_CUSTOMER c on c.IDCustomer=t.IDCustomer 
where c.IDCustomer in (select top 100 t.IDCustomer from FACT_TRANSACTIONS t inner join
DIM_CUSTOMER c on c.IDCustomer=t.IDCustomer group by t.IDCustomer order by sum(t.TotalPrice) desc)
group by c.customer_name,year(t.date)) t2 
on t1.customer_name=t2.customer_name and t2.Year=t1.year-1

--Q10--END
	